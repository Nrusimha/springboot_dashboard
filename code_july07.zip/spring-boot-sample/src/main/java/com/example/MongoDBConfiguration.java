/*package com.example;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;

@Configuration
public class MongoDBConfiguration extends AbstractMongoClientConfiguration {

    @Value("${spring.data.mongodb.uri}")
    private String mongoUri;

    @Override
    protected String getDatabaseName() {
        // Set the MongoDB database name
        return "your_database_name";
    }

    @Override
    protected void configureClientSettings(MongoClientSettings.Builder builder) {
        // Set the MongoDB connection URI
        builder.applyConnectionString(new ConnectionString(mongoUri));
    }
}*/
