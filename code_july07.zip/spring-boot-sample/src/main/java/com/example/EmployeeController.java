package com.example;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	
	 private final MongoTemplate mongoTemplate;
	 private final EmployeeRepository   employeeRepository ;


	    @Autowired
	    public EmployeeController(EmployeeRepository employeeRepository) {
	        this.mongoTemplate = null;
			this.employeeRepository = employeeRepository;
	    }
	    
    @GetMapping("/employees")
    public List<EmployeeDataEntity> getAllEmployees() {
        // Replace this with your actual data source or database query
        List<EmployeeDataEntity> employees = getEmployeesFromDataSource();
        return employeeRepository.findAll();
        
    }

    private List<EmployeeDataEntity> getEmployeesFromDataSource() {
        // Simulating data retrieval from a data source
        List<EmployeeDataEntity> employees = new ArrayList<>();

 
        return employees;
    }
}

