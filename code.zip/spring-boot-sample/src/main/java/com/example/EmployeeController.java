package com.example;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeController {

    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        // Replace this with your actual data source or database query
        List<Employee> employees = getEmployeesFromDataSource();
        return employees;
    }

    private List<Employee> getEmployeesFromDataSource() {
        // Simulating data retrieval from a data source
        List<Employee> employees = new ArrayList<>();

        // Add sample employee data
        employees.add(new Employee("1", "John Doe", "1000 USD"));
        employees.add(new Employee("2", "Jane Smith", "2000 USD"));
        employees.add(new Employee("3", "Mike Johnson", "3000 USD"));

        return employees;
    }
}

class Employee {
    private String id;
    private String name;
    private String email;

    // Constructors, getters, and setters

    public Employee(String id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    // Getters and setters...

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}